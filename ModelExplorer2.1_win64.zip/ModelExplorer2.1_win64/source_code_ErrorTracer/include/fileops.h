#ifndef FILEOPS_H_INCLUDED
#define FILEOPS_H_INCLUDED

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <fstream>

using namespace std;

int string_to_file(string &write_file,string file_path);

#endif // FILEOPS_H_INCLUDED